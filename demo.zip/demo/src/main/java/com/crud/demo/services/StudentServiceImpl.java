package com.crud.demo.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.demo.models.Student;
import com.crud.demo.repository.StudentRepository;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentRepository studentRepository;

	@Override
	
	public Student findByFirstName(String firstName) {
		return studentRepository.findByFirstName(firstName);
	}



	@Override
	
	public Student save(Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student);
	}

	@Override
	@Transactional
	public Student findById(Long id) {
		// TODO Auto-generated method stub
		
		 return studentRepository.findById(id).get();
	}

	@Override
	
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}

	@Override
	
	public void delete(Student student) {
		studentRepository.delete(student);

	}

	

}
