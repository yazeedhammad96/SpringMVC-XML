package com.crud.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crud.demo.models.Student;
import com.crud.demo.services.StudentService;
import com.crud.demo.services.StudentServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value="Controller", description="Crud System for Students")
@RequestMapping("student")
public class CRUDRestController {

	@Autowired
	StudentService studentServiceImpl;

	@GetMapping
	public String hello() {
		return "Hello";
	}

	@ApiOperation("Get the Student based on Id")
	@GetMapping("/get/{id}")
	public Student getOne(@PathVariable("id") Long id) {
		return studentServiceImpl.findById(id);
	}
	@ApiOperation(value = "View a list of available Students",response = List.class)
    
	@GetMapping("/getAll")
	public List<Student> findAll() {
		return studentServiceImpl.findAll();
	}
	@ApiOperation(value="Add ")
	@PostMapping("/add")
	public Student save(@RequestBody Student student) {
		return studentServiceImpl.save(student);
	}
	@PutMapping("/edit")
	public Student edit(@RequestBody Student student) {
		return studentServiceImpl.save(student);
	}
	@DeleteMapping("/delete")
	public void delete(@RequestBody Student student) {
		 studentServiceImpl.delete(student);
	}
	@PostMapping("/findByFirstName/{firstName}")
	public Student findByFirstName(@PathVariable("firstName") String firstName) {
		return studentServiceImpl.findByFirstName(firstName);
	}

}
