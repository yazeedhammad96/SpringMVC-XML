package com.crud.demo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.crud.demo.services.StudentService;

@Controller
@RequestMapping(value="studentC")
@EnableWebMvc
public class CRUDController {

	@Autowired
	StudentService studentServiceImpl;
	@GetMapping()
	public @ResponseBody String hello() {

		return "HIIIIIII";
	}
	
	@GetMapping("/index")
	public ModelAndView index() {
		ModelAndView model=new ModelAndView("list");
		model.addObject("listStudents",studentServiceImpl.findAll());
		return model;
	}
}
