package com.crud.demo.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.Table;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.crud.demo.models.Student;
public interface StudentRepository extends CrudRepository<Student, Long> {

	Student findByFirstName(String firstName);

	@Query(value="select * from student" ,nativeQuery=true)
	List<Student> findAll();
	
	Optional<Student> findById(Long Id);

}
