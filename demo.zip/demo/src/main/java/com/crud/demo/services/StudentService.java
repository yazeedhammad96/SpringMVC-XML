package com.crud.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;

import com.crud.demo.models.Student;

public interface StudentService {
	Student findByFirstName(String firstName);


	Student save(Student student);

	Student findById(Long id);

	List<Student> findAll();

	void delete(Student student);


}
