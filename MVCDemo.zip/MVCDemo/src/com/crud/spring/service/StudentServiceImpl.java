package com.crud.spring.service;

import java.util.List;

import javax.xml.ws.ServiceMode;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.crud.spring.entity.Student;



@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private com.crud.spring.dao.StudentDAO studentDAO;

	@Override
	@Transactional
	public List<Student> getStudents() {
		return studentDAO.getStudents();
	}

	@Override
	@Transactional
	public void saveStudent(Student thestudent) {

		studentDAO.saveStudent(thestudent);
	}

	@Override
	@Transactional
	public Student getStudent(Long theId) {
		
		return studentDAO.getStudent(theId);
	}

	@Override
	@Transactional
	public void deleteStudent(Student student) {
		
		studentDAO.deleteStudent(student);
	}
	@Override
	@Transactional
	public void updateStudent(Student student) {
		
		studentDAO.updateStudent(student);
	}
}





