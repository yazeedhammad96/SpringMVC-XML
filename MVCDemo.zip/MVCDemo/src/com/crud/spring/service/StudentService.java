package com.crud.spring.service;

import java.util.List;

import com.crud.spring.entity.Student;;

public interface StudentService {

	public List<Student> getStudents();

	public void saveStudent(Student Student);

	public Student getStudent(Long long1);

	public void deleteStudent(Student student);

	void updateStudent(Student Student);
	
}
