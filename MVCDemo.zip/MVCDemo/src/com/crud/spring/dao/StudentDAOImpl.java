package com.crud.spring.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.crud.spring.DB.DBHibernateCon;
import com.crud.spring.entity.Student;

@Repository
public class StudentDAOImpl implements StudentDAO {

	@Autowired
 DBHibernateCon dBHibernateCon;

	@Override
	public List<Student> getStudents() {
		return dBHibernateCon.getSession().createQuery("from Student").list();
	}

	@Override
	public void saveStudent(Student thestudent) {

		dBHibernateCon.getSession().insert(thestudent);
	}

	@Override
	public Student getStudent(Long theId) {
		return (Student) dBHibernateCon.getSession().get(Student.class, theId);
	}

	@Override
	public void deleteStudent(Student student) {

		dBHibernateCon.getSession().delete(student);
	}

	@Override
	public void updateStudent(Student theStudent) {

		dBHibernateCon.getSession().update(theStudent);
	}

}