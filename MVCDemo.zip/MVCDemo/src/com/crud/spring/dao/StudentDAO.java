package com.crud.spring.dao;

import java.util.List;

import com.crud.spring.entity.Student;

public interface StudentDAO {

	public List<Student> getStudents();

	public void saveStudent(Student theStudent);

	public void updateStudent(Student theStudent);

	public Student getStudent(Long theId);

	public void deleteStudent(Student student);

}
