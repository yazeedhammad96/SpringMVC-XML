package com.crud.spring.DB;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DBHibernateCon {

	@Autowired
	private SessionFactory sessionFactory;

	private StatelessSession session;
	

	public synchronized StatelessSession getSession() {
		if (session == null) {
			session = sessionFactory.openStatelessSession();
			return session;

		} else {
			return session;
		}

	}
}
